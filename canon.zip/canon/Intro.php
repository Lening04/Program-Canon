<Html>
<body>
	<?PHP
		Echo"Kopi seperti Yang kita ketahui selama ini .....";
	?>
	</body>
</Html>