-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 03, 2016 at 07:56 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `canon`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE IF NOT EXISTS `tb_admin` (
  `id_admin` varchar(50) NOT NULL,
  `id_level` varchar(20) NOT NULL,
  `tanggal` datetime NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--


-- --------------------------------------------------------

--
-- Table structure for table `tb_harga`
--

CREATE TABLE IF NOT EXISTS `tb_harga` (
  `id_harga` varchar(50) NOT NULL,
  `tanggal` datetime NOT NULL,
  `harga` varchar(20) NOT NULL,
  PRIMARY KEY (`id_harga`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_harga`
--


-- --------------------------------------------------------

--
-- Table structure for table `tb_kamera`
--

CREATE TABLE IF NOT EXISTS `tb_kamera` (
  `id_kamera` varchar(20) NOT NULL,
  `id_admin` varchar(50) NOT NULL,
  `id_harga` varchar(50) NOT NULL,
  `nama_kamera` varchar(50) NOT NULL,
  `jenis_kamera` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `sensor` varchar(50) NOT NULL,
  `memori` varchar(50) NOT NULL,
  `flash` varchar(50) NOT NULL,
  `megapixel` char(10) NOT NULL,
  PRIMARY KEY (`id_kamera`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kamera`
--


-- --------------------------------------------------------

--
-- Table structure for table `tb_level_admin`
--

CREATE TABLE IF NOT EXISTS `tb_level_admin` (
  `id_level` varchar(20) NOT NULL,
  `nama_level` varchar(50) NOT NULL,
  `level_user` varchar(20) NOT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_level_admin`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
