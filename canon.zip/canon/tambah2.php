<?php
include('conn.php');
include ('js/fungsi.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CANON</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="index.php"><img src="img/Canon_logo.png" width="100" height="25"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php#about">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#contact">Contact</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#product">Product</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#compare">Compare</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	<section class="bg-primary-product" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Add Product Canon</h2>
					
                    <hr class="primary">
                </div>
            </div>
	<div class="content">
				<?php
				if(isset($_POST['add'])){
				$id_kamera	= $_POST['id_kamera'];
				$nama_kamera	= $_POST['nama_kamera'];
				$harga_kamera	= $_POST['Harga'];
				$jenis_kamera	= $_POST['jenis_kamera'];
				$processor	= $_POST['processor'];
				$sensor	= $_POST['sensor'];
				$flash	= $_POST['flash'];
				$megapixel	= $_POST['megapixel'];
				$sumber= $_FILES ['gambar']['tmp_name'];
				$target = 'img/';
				$nama_gambar= $_FILES['gambar']['name'];
				$datakode = buatKode("canon","K"); 
					
				

				
	//insert ke tabel
	$pindah= move_uploaded_file($sumber, $target.$nama_gambar);
	if($pindah){ 
	$query = "INSERT INTO canon(ID_KAMERA,NAMA_KAMERA,ID_JENIS,ID_PROCESSOR,ID_SENSOR,HARGA,MEGAPIXELS,FLASH,gambar) 
	VALUES('$datakode','$nama_kamera','$jenis_kamera','$processor','$sensor','$harga_kamera','$megapixel','$flash','$nama_gambar')";
	$sql = mysql_query ($query) or die (mysql_error());
	if ($sql) {
			echo"<script>alert('Data produk kamera telah berhasil ditambahkan !)</script>";
	} else {
			echo"<script>alert('Data produk kamera gagal ditambahkan !)</script>";
	}
	} else{
			echo"<script>alert('gambar gagal di uplod !)</script>";
	}
				}
				?>
	
	<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
		 <div class="row">
						<div class="col-lg-6">
							<div class="form-group">
								<label class="col-sm-3 control-label">ID Kamera</label>
								<div class="col-sm-6">
									<input type="text" name="id_kamera" value ="<?php $datakode = buatKode("canon","K"); 
									echo "$datakode";?>" class="form-control" placeholder="ID kamera" 
									 disabled>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Nama Kamera</label>
								<div class="col-sm-6">
									<input type="text" name="nama_kamera" class="form-control" placeholder="nama kamera" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Harga Kamera</label>
								<div class="col-sm-6">
									<input type="text" name="Harga" class="form-control" placeholder="Harga" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Jenis Kamera</label>
								<div class="col-sm-6">
										
									<select name='jenis_kamera' class='form-control'>
										<?php echo 
									$tampil =mysql_query("select * from jeniskamera");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_JENIS] selected>$row[NAMA_JENIS]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Processor</label>
								<div class="col-sm-6">
									<?php echo "<select name='processor' class='form-control'>";
									$tampil =mysql_query("select * from processor");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_PROCESSOR] selected>$row[NAMA_PROCESSOR]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
						</div>
					
					
						<div class="col-lg-6">
							<div class="form-group">
									<label class="col-sm-3 control-label">Sensor</label>
								<div class="col-sm-6">
									<?php echo "<select name='sensor' class='form-control'>";
									$tampil =mysql_query("select * from sensorsize");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_SENSOR] selected>$row[NAMA_SENSOR]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">Flash</label>
									<div class="col-sm-6">
										<SELECT id='flash' name='flash' class='form-control'>
											<option value="Tidak"> Tidak Ada Flash</option>
											<option value="Ya"> Ada Flash</option>
										</select>
									</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">Megapixel</label>
									<div class="col-sm-6">
										<input type="text" name="megapixel" class="form-control" placeholder="megapixel" required>
									</div>
							</div>
							<div class="form-group">
<label class="col-sm-3 control-label">Foto Product</label>
<div class="col-sm-6">
<input type="file" name="gambar"/>
									</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">&nbsp;</label>
									<div class="col-sm-6">
<input type="submit" name="add" class="btn btn-sm btn-primary" value="Simpan">
<input type="reset" class="btn btn-sm btn-danger"value="Batal" />
									</div>
							</div>
						</div>
		</div>
	</form> 
	
	<div class="table-responsive">
	<div class="col-lg-12 text-center">
                    <h2 class="section-heading">Data Product Canon</h2>
                    <hr class="primary">
                </div>
	<table class="table table-striped table-hover">
	<div class=col-lg-12>
	<tr>
		<th>No</th>
		<th>ID Kamera</th>
		<th>Nama Kamera</th>
		<th>Jenis Kamera</th>
		<th>Processor</th>
		<th>Sensor</th>
		<th>Harga Kamera</th>
		<th>Megapixel</th>
		<th>Flash</th>
		<th>product</th>
		<th>Action</th>
	</tr>
	<?php
	$no = 1;
	$tampil = "Select ID_KAMERA, Nama_Kamera, J.NAMA_JENIS, P.NAMA_PROCESSOR, S.NAMA_SENSOR, Harga, Megapixels, Flash,gambar
	from canon as C inner join 
	jeniskamera as J on C.ID_JENIS=J.ID_JENIS
	inner join 
	processor as P on C.ID_PROCESSOR=P.ID_PROCESSOR
	INNER JOIN 
	sensorsize as S on C.ID_SENSOR=S.ID_SENSOR
	order by ID_KAMERA"; 
	$sql = mysql_query($tampil);
					while ($hasil = mysql_fetch_array ($sql)){
					$ID_Kamera = $hasil['ID_KAMERA'];
					$Nama_Kamera = $hasil['Nama_Kamera'];
					$NAMA_JENIS = $hasil['NAMA_JENIS'];
					$NAMA_PROCESSOR = $hasil['NAMA_PROCESSOR'];
					$NAMA_SENSOR = $hasil['NAMA_SENSOR'];
					$Harga = $hasil['Harga'];
					$Megapixels = $hasil['Megapixels'];
					$Flash = $hasil['Flash'];
					$gambars = $hasil['gambar'];
					?>
					<tr>
					<th><?php echo $no; ?></th>
					<th><?php echo $ID_Kamera; ?></th>
					<th><?php echo $Nama_Kamera; ?></th>
					<th><?php echo $NAMA_JENIS; ?></th>
					<th><?php echo $NAMA_PROCESSOR; ?></th>
					<th><?php echo $NAMA_SENSOR; ?></th>
					<th><?php echo $Harga; ?></th>
					<th><?php echo $Megapixels; ?></th>
					<th><?php echo $Flash; ?></th>
					<th align="center"><img src="img/<?php echo $gambars; ?>" width="120px"></th>
					<th> 
			<a href="edit.php?page=edit&ID_Kamera=<?php echo $ID_Kamera; ?>"><input type="submit" name="Input" class="btn btn-info" value="Edit"></a><br/>
			
			<a href="delete.php?page=delete&ID_Kamera=<?php echo $ID_Kamera; ?>" onclick="return confirm('Anda yakin akan menghapus data <?php echo $Nama_Kamera; ?> ?')"><input class="btn btn-sm btn-danger" type="button" name="" value=" Delete "/></a></th>
					</tr>
			<?php $no++; }?>
	</table>
	</div>
	</div>
	</div>
    </section>
	
   
	<!--Copy Right Template bootstrap by startbootstrap.com -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

</body>
</html>
