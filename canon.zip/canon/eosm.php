<?php
include('conn.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CANON</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="index.php#page-top"><img src="img/Canon_logo.png" width="100" height="25"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php#about">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#contact">Contact</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#product">Product</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#compare">Compare</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1><img src="img/Canon_logo.png" width="180" height="50"></h1>
                <hr>
                <p><i>Canon See Impossible</i> There are no limits to what an image can do!</p>
            </div>
        </div>
    </header>

    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">We've got what you need!</h2>
                    <hr class="light">
                    <p class="text-faded">Aktifitas Canon di Indonesia dipantau oleh Canon Singapore Pte. Ltd., yang merupakan kantor pusat regional dari Canon di Asia Selatan & Asia Tenggara. Canon Singapore mengarahkan strategi penjualan, pemasaran, dan pelayanan dan memimpin 18 negara lainnya termasuk anak perusahaan di India, Malaysia, Thailand dan Vietnam.</p>
                    <a href="#" class="btn btn-default btn-xl">Get Started!</a>
                </div>
            </div>
        </div>
    </section>
	
	 <section class="bg-primary-contact" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Let's Get in touch</h2>
                    <hr class="primary">
                    <p>Untuk Informasi Lebih Lanjut, bisa hubungi ke </p>
                </div>
                <div class="col-lg-4 col-lg-offset-2 text-center">
                    <i class="fa fa-phone fa-3x wow bounceIn"></i>
                    <p>123-456-6789</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-envelope-o fa-3x wow bounceIn" data-wow-delay=".1s"></i>
                    <p>service@canon.com</p>
                </div>
            </div>
        </div>
    </section>
	

    <section class="bg-primary-product" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Produk Canon</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
        <div class="container">
			<ul class="nav nav-tabs nav-justified">
				<li role="presentation"><a href="index.php#product">EOS</a></li>
				<li role="presentation" class="active"><a href="eosm.php">EOSM</a></li>
				<div class="row">
				 <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/eos-5d-mk3-kit1_b.jpg" alt="Atlas png" width="140" height="140">
                        <h3>Canon Eosm 5D</h3>
                       <p class="text-muted">Rp. 33.450.000,00 </p>
                    </div>
                </div>
				 <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/eos-5ds-body_b.jpg" alt="Atlas png" width="140" height="140">
                        <h3>Canon EosM 5DS</h3>
                       <p class="text-muted">Rp. 47.000.000,00 </p>
                    </div>
                </div>
				 <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/eos-7d-mk2-kit1_b.jpg" alt="Atlas png" width="140" height="140">
                        <h3>Canon EosM 7D</h3>
                       <p class="text-muted">Rp. 17.300.000,00 </p>
                    </div>
                </div>
				 <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/eos-100d-kit1_b.jpg" alt="Atlas png" width="140" height="140">
                        <h3>Canon EosM 100D</h3>
                       <p class="text-muted">Rp. 7.700.000,00 </p>

                    </div>
                </div>
				</div>
			</ul>
        </div>
		<div class="row">
		</div>
		<div class="container text-center">
            <div class="row">
                <a href="tambah2.php" class="btn btn-default btn-xl wow tada">Add Product!</a>
            </div>
        </div>
    </section>

	<section class="bg-primary-compare" id="compare">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Input Kriteria</h2>
					
                    <hr class="primary">
                </div>
            </div>
	<div class="content">

	<form class="form-horizontal" action="matrik.php" method="post">
	<div class="container">
		<div class="row">
             <div class="col-xs-6 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/harga.png"  width="140" height="140">
                        <h3>HARGA</h3>
						<p class="text">choose</p>
                       <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions1" id="inlineRadio1" value=1> 1
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions1" id="inlineRadio1" value=3> 3
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions1" id="inlineRadio1" value=5> 5
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions1" id="inlineRadio1" value=7> 7
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions1" id="inlineRadio1" value=9> 9
						</label>
                    </div>
                </div>
			 <div class="col-xs-6 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                       <img class="img-circle wow bounceIn" src="img/Headings/megapixel.jpg"  width="140" height="140" data-wow-delay=".1s">
                        <h3>MEGAPIXEL</h3>
                        <p class="text">choose</p>
                       <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions2" id="inlineRadio2" value=1> 1
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions2" id="inlineRadio2" value=3> 3
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions2" id="inlineRadio2" value=5> 5
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions2" id="inlineRadio2" value=7> 7
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions2" id="inlineRadio2" value=9> 9
						</label>

                    </div>
                </div>
				<div class="col-xs-6 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                      <img class="img-circle wow bounceIn" src="img/Headings/sensor.jpg" width="140" height="140" data-wow-delay=".2s">
                        <h3>SENSOR</h3>
                        <p class="text">choose</p>
                       <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions3" id="inlineRadio3" value=1> 1
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions3" id="inlineRadio3" value=3> 3
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions3" id="inlineRadio3" value=5> 5
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions3" id="inlineRadio3" value=7> 7
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions3" id="inlineRadio3" value=9> 9
						</label>

                    </div>
                </div>
			<div class="col-xs-6 col-md-6 text-center">
                    <div class="service-box" data-wow-delay=".3s">
                      <img class="img-circle wow bounceIn" src="img/Headings/processor.png" width="140" height="140" data-wow-delay=".2s">
                        <h3>PROCESSOR</h3>
                        <p class="text">choose</p>
                       <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions4" id="inlineRadio4" value=1> 1
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions4" id="inlineRadio4" value=3> 3
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions4" id="inlineRadio4" value=5> 5
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions4" id="inlineRadio4" value=7> 7
						</label>
						 <label class="radio-inline">
						<input type="radio" name="inlineRadioOptions4" id="inlineRadio4" value=9> 9
						</label>

                    </div>
                </div>
				
                </div>
					<div class="container text-center">
				 <div class="row">
				 <a href="#" onclick="return confirm('Pilih sesuai dengan kebutuhan')"><input class="btn btn-default btn-xl wow tada" type="button" name="" value=" ? "/></a>
				<input class="btn btn-default btn-xl wow tada" name="submit" type="submit" value="Search !">
            </div>
            </div>
        </div>
	</form> 
	</div>
    </section>
	
   <?include "Modul Gak Kepakai/portfolio.php"?>

    <aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
                <h2>SHOP CANON!</h2>
            </div>
        </div>
    </aside>
	

   
	<!--Copy Right Template bootstrap by startbootstrap.com -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

</body>

</html>
