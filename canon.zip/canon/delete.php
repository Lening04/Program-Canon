<?php
include "conn.php";

if (isset($_GET['ID_Kamera'])) {
	$ID_Kamera = $_GET['ID_Kamera'];
} else {
	die ("Error. No ID_Kamera Selected! ");	
}
?>
<div id="content">
	<?php
	//proses delete berita
	if (!empty($ID_Kamera) && $ID_Kamera != "") {
		$query = "DELETE FROM canon WHERE ID_Kamera='$ID_Kamera'";
		$sql = mysql_query ($query);
		if ($sql) {
			echo"<script>alert('Data product telah berhasil dihapus !',document.location.href='tambah2.php')</script>";	
		} else {
			echo"<script>alert('Data product gagal dihapus !',document.location.href='tambah2.php')</script>";	
		}
		echo "Klik <a href='tambah2.php'>di sini</a> untuk kembali ke halaman data product";
	} else {
		die ("Access Denied");	
	}
	?>
</div>