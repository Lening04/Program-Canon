<?php
include('conn.php');
if (isset($_GET['ID_Kamera'])) {
	$ID_Kamera = $_GET['ID_Kamera'];
} else {
	die ("Error. ID Kamera Selected! ");	
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CANON</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="index.php"><img src="img/Canon_logo.png" width="100" height="25"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php#about">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#contact">Contact</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#product">Product</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php#compare">Compare</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<?php


$query = "Select ID_KAMERA, Nama_Kamera, J.NAMA_JENIS, P.NAMA_PROCESSOR, S.NAMA_SENSOR, Harga, Megapixels, Flash,gambar
	from canon as C inner join 
	jeniskamera as J on C.ID_JENIS=J.ID_JENIS
	inner join 
	processor as P on C.ID_PROCESSOR=P.ID_PROCESSOR
	INNER JOIN 
	sensorsize as S on C.ID_SENSOR=S.ID_SENSOR
	WHERE ID_Kamera='$ID_Kamera'";
$sql = mysql_query ($query);
$hasil = mysql_fetch_array ($sql);
$ID_Kamera = $hasil['ID_KAMERA'];
$Nama_Kamera = stripslashes ($hasil['Nama_Kamera']);
$nama_jenis = stripslashes ($hasil['NAMA_JENIS']);
$nama_processor = stripslashes ($hasil['NAMA_PROCESSOR']);
$nama_sensor = stripslashes ($hasil['NAMA_SENSOR']);
$Harga = stripslashes ($hasil['Harga']);
$Megapixels = stripslashes ($hasil['Megapixels']);
$Flash = stripslashes ($hasil['Flash']);
$gambar = stripslashes ($hasil['gambar']);


//proses edit
if (isset($_POST['Edit'])) {
	$ID_Kamera = $_POST['sID_Kamera'];
	$Nama_Kamerap = addslashes (strip_tags ($_POST['Nama_Kamerap']));
	$nama_jenisp = addslashes (strip_tags ($_POST['nama_jenisp']));
	$nama_processorp = addslashes (strip_tags ($_POST['nama_processorp']));
	$nama_sensorp = addslashes (strip_tags ($_POST['nama_sensorp']));
	$Hargap = addslashes (strip_tags ($_POST['Hargap']));
	$Megapixelsp = addslashes (strip_tags ($_POST['Megapixelsp']));
	$Flashp = addslashes (strip_tags ($_POST['Flashp']));
	$sumber= $_FILES ['gambar']['tmp_name'];
	$target = 'img/';
	$nama_gambar= $_FILES['gambar']['name'];

	
	//update data
	$pindah= move_uploaded_file($sumber, $target.$nama_gambar);
	if($pindah){
	$query = "UPDATE canon SET NAMA_KAMERA='$Nama_Kamerap',ID_JENIS='$nama_jenisp',ID_PROCESSOR='$nama_processorp',ID_SENSOR='$nama_sensorp',HARGA='$Hargap',MEGAPIXELS='$Megapixelsp',FLASH='$Flashp',gambar='$nama_gambar' WHERE ID_KAMERA='$ID_Kamera'";
	$sql = mysql_query ($query);
	if ($sql) {
			echo"<script>alert('Data product telah berhasil diedit !',document.location.href='tambah2.php')</script>";
	} else {
			echo"<script>alert('Data product gagal diedit !',document.location.href='tambah2.php')</script>";
	}
	}else {
		echo"<script>alert('gambar gagal diedit !',document.location.href='tambah2.php')</script>";
	}
}
?>

	<section class="bg-primary-product" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Edit Product Canon</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
		<form class="form-horizontal" action="" name="input" method="POST" enctype="multipart/form-data">
		 <div class="row">
						<div class="col-lg-6">
							<div class="form-group">
								<label class="col-sm-3 control-label">ID Kamera</label>
								<div class="col-sm-6">
									<th><?php echo $ID_Kamera; ?></th>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Nama Kamera</label>
								<div class="col-sm-6">
									<input type="text" name="Nama_Kamerap" class="form-control" value ="<?php echo $Nama_Kamera; ?>" >
									</input>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Harga Kamera</label>
								<div class="col-sm-6">
									<input type="text" name="Hargap" class="form-control" value="<?php echo $Harga; ?>">
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Jenis Kamera</label>
								<div class="col-sm-6" >
									<?php echo "<select name='nama_jenisp' class='form-control'>";
									$tampil =mysql_query("select * from jeniskamera");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_JENIS] selected>$row[NAMA_JENIS]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Processor</label>
								<div class="col-sm-6">
									<?php echo "<select name='nama_processorp' class='form-control'>";
									$tampil =mysql_query("select * from processor");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_PROCESSOR] selected>$row[NAMA_PROCESSOR]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
									<label class="col-sm-3 control-label">Sensor</label>
								<div class="col-sm-6">
									<?php echo "<select name='nama_sensorp' class='form-control'>";
									$tampil =mysql_query("select * from sensorsize");
									while ($row=mysql_fetch_array($tampil))
									{
										echo"<option value=$row[ID_SENSOR] selected>$row[NAMA_SENSOR]</option>";
									}
										echo"</select>";
									?>
								</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">Megapixel</label>
									<div class="col-sm-6">
										<input type="text" name="Megapixelsp" class="form-control" value ="<?php echo $Megapixels; ?>">
									</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">Flash</label>
									<div class="col-sm-6">
										<SELECT id='Flash' name='Flashp' class='form-control'>
											<option value="Tidak"> Tidak Ada Flash</option>
											<option value="Ya"> Ada Flash</option>
										</select>
									</div>
							</div>
							
							<div class="form-group">
									<label class="col-sm-3 control-label">Foto Product</label>
									<div class="col-sm-6">
									<img src="img/<?php echo $gambar; ?>" width="120px">
										<input type="file" name="gambar"/>
										
									</div>
							</div>
							<div class="form-group">
									<label class="col-sm-3 control-label">&nbsp;</label>
									<div class="col-sm-6">
						<input type="hidden" name="sID_Kamera" value="<?php echo $ID_Kamera; ?>">
						<input type="submit" name="Edit" class="btn btn-sm btn-primary" value="Simpan">
<input type="reset" class="btn btn-sm btn-danger"value="Batal" />
<a href="tambah2.php"><input type="button" name="" class="btn btn-sm btn-primary" value=" Kembali "/></a>
									</div>
							</div>
						</div>
		</div>
	</form> 
		
        </div>
    </section>

   
	<!--Copy Right Template bootstrap by startbootstrap.com -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

</body>

</html>
