<html>
<Body>
<?php include'radio_value.php'; ?>
<?php

$Hrs = $_POST['inlineRadioOptions1'];
$Mps = $_POST['inlineRadioOptions2'];
$Sss = $_POST['inlineRadioOptions3'];
$Prs = $_POST['inlineRadioOptions4'];
$user = array($Hrs,$Mps,$Sss,$Prs);
$Hr = $user[0];
$Mp = $user[1];
$Ss = $user[2];
$Pr = $user[3];

Echo "<h2>Prioritas inputan user </h2>";
Echo "<h3>Harga = ".$Hr. "</h3>";
Echo "<h3>MegaPixels = ".$Mp. "</h3>";
Echo "<h3>Sensor = ".$Ss. "</h3>";
Echo "<h3>Processor = ".$Pr. "</h3>";


$HH = number_format($Hr / $Hr,2); // Harga : Harga
$HM = number_format($Hr / $Mp,2); // Harga : Megapixels
$HS = number_format($Hr / $Ss,2); // Harga : Sensor
$HP = number_format($Hr / $Pr,2);// Harga : Processor

$MH = number_format($Mp / $Hr,2); // Megapixel : Harga
$MM = number_format($Mp / $Mp,2); // Megapixel : Megapixel
$MS = number_format($Mp / $Ss,2); // Megapixel : Sensor
$MP = number_format($Mp / $Pr,2); // Megapixel : Processor

$SH = number_format($Ss / $Hr,2); // Sensor : Harga
$SM = number_format($Ss / $Mp,2); // Sensor : Megapixel
$SS = number_format($Ss / $Ss,2); // Sensor : Sensor
$SP = number_format($Ss / $Pr,2); // Sensor : Processor

$PH = number_format($Pr / $Hr,2); // Processor : Harga
$PM = number_format($Pr / $Mp,2); // Processor : Megapixel
$PS = number_format($Pr / $Ss,2); // Processor : Sensor
$PP = number_format($Pr / $Pr,2); // Processor : Processor

$TH = number_format(($HH+$MH+$SH+$PH),2);// Total Harga
$TM = number_format(($HM+$MM+$SM+$PM),2);// Total Megapixel
$TS = number_format(($HS+$MS+$SS+$PS),2);// Total Sensor
$TP = number_format(($HP+$MP+$SP+$PP),2);// Total Processor
?>

<H1>Tabel Prioritas Inputan Oleh User</H1>
<table border="1" style="width:50%">
	<tr>
		<td>M. User</td>
		<td>harga Hr</td>
		<td>Megapixel Mp</td>	
		<td>Sensor Ss</td>
		<td>Processor Pr</td>

		
	</tr>
  <tr>
    <td>Harga Hr</td>
	<td><?php echo $HH;?></td>
	<td><?php echo $HM;?></td>
	<td><?php echo $HS;?></td>
	<td><?php echo $HP;?></td>
	</tr>
	<tr>
    <td>Megapixels Mp</td>
	<td><?php echo $MH;?></td>
	<td><?php echo $MM;?></td>
	<td><?php echo $MS;?></td>
	<td><?php echo $MP;?></td>
	</tr>
	<tr>
    <td>Sensor Ss</td>
	<td><?php echo $SH;?></td>
	<td><?php echo $SM;?></td>
	<td><?php echo $SS;?></td>
	<td><?php echo $SP;?></td>
	</tr>
	<tr>
    <td>Processor Pr</td>
	<td><?php echo $PH;?></td>
	<td><?php echo $PM;?></td>
	<td><?php echo $PS;?></td>
	<td><?php echo $PP;?></td>
	</tr>
	<tr>
	<td>Total</td>
	<td><b><?php echo $TH;?></b></td>
	<td><b><?php echo $TM;?></b></td>
	<td><b><?php echo $TS;?></b></td>
	<td><b><?php echo $TP;?></b></td>
	</tr>
  </tr>
  
  
</table>
</BR>

<?php 

//Proses Normalisasi
$NH1 = number_format($HH / $TH,2); // Harga : Total Harga
$NM1 = number_format($MH / $TH,2); // Harga : Total Harga
$NS1 = number_format($SH / $TH,2); // Harga : Total Harga
$NP1 = number_format($PH / $TH,2); // Harga : Total Harga

$NH2 = number_format($HM / $TM,2); // Harga : Total Megapixel
$NM2 = number_format($MM / $TM,2); // Harga : Total Megapixel
$NS2 = number_format($SM / $TM,2); // Harga : Total Megapixel
$NP2 = number_format($PM / $TM,2); // Harga : Total Megapixel

$NH3 = number_format($HS / $TS,2); // Harga : Total Sensor
$NM3 = number_format($MS / $TS,2); // Harga : Total Sensor
$NS3 = number_format($SS / $TS,2); // Harga : Total Sensor
$NP3 = number_format($PS / $TS,2); // Harga : Total Sensor

$NH4 = number_format($HP / $TP,2); // Harga : Total Processor
$NM4 = number_format($MP / $TP,2); // Harga : Total Processor
$NS4 = number_format($SP / $TP,2); // Harga : Total Processor
$NP4 = number_format($PP / $TP,2); // Harga : Total Processor

$TN1 = number_format(($NH1+$NM1+$NS1+$NP1),2);// Total Normalisasi 1
$TN2 = number_format(($NH2+$NM2+$NS2+$NP2),2);// Total Normalisasi 1
$TN3 = number_format(($NH3+$NM3+$NS3+$NP3),2);// Total Normalisasi 1
$TN4 = number_format(($NH4+$NM4+$NS4+$NP4),2);// Total Normalisasi 1

$R1 = number_format(($NH1+$NH2+$NH3+$NH4)/4,2); //rata rata harga
$R2 = number_format(($NM1+$NM2+$NM3+$NM4)/4,2); //rata rata harga
$R3 = number_format(($NS1+$NS2+$NS3+$NS4)/4,2); //rata rata harga
$R4 = number_format(($NP1+$NP2+$NP3+$NP4)/4,2); //rata rata harga

$H1 = number_format(($NH1*$R1+$NH2*$R2+$NH3*$R3+$NH4*$R4),2); //Hasil Matriks 1
$H2 = number_format(($NM1*$R1+$NM2*$R2+$NM3*$R3+$NM4*$R4),2); //Hasil Matriks 1
$H3 = number_format(($NS1*$R1+$NS2*$R2+$NS3*$R3+$NS4*$R4),2); //Hasil Matriks 1
$H4 = number_format(($NP1*$R1+$NP2*$R2+$NP3*$R3+$NP4*$R4),2); //Hasil Matriks 1


?>
	<H1>NORMALISASI</H1>
<table border="1" style="width:50%">
	<tr>
		<td>Normalisasi</td>
		<td>harga</td>
		<td>Megapixel</td>	
		<td>Sensor</td>
		<td>Processor</td>
		<td>Rata Rata</td>
		<td>hasil</td>
	</tr>
  <tr>
    <td>Harga</td>
	<td><?php echo $NH1;?></td>
	<td><?php echo $NH2;?></td>
	<td><?php echo $NH3;?></td>
	<td><?php echo $NH4;?></td>
	<td><?php echo $R1;?></td>
	<td><?php echo $H1;?></td>
	</tr>
	<tr>
    <td>Megapixels</td>
	<td><?php echo $NM1;?></td>
	<td><?php echo $NM2;?></td>
	<td><?php echo $NM3;?></td>
	<td><?php echo $NM4;?></td>
	<td><?php echo $R2;?></td>
	<td><?php echo $H2;?></td>
	</tr>
	<tr>
    <td>Sensor</td>
	<td><?php echo $NS1;?></td>
	<td><?php echo $NS2;?></td>
	<td><?php echo $NS3;?></td>
	<td><?php echo $NS4;?></td>
	<td><?php echo $R3;?></td>
	<td><?php echo $H3;?></td>
	</tr>
	<tr>
    <td>Processor</td>
	<td><?php echo $NP1;?></td>
	<td><?php echo $NP2;?></td>
	<td><?php echo $NP3;?></td>
	<td><?php echo $NP4;?></td>
	<td><?php echo $R4;?></td>
	<td><?php echo $H4;?></td>
	</tr>
	<tr>
	<td>Total</td>
	<td><?php echo $TN1;?></td>
	<td><?php echo $TN2;?></td>
	<td><?php echo $TN3;?></td>
	<td><?php echo $TN4;?></td>
	</tr>
  </tr>
</table>
</Br>
</Br>

<h1>Tabel Kamera<h1>

<?php
//Data Kamera
$kamera = array
  (
  array("Canon 750 D",10450000,24,3,1),
  array("Canon 1200 D",5375000,18,1,2),
  array("Canon 760 D",15625000,24,3,1),
  array("Canon 5D MARK III",38875000,22,2,1)
  );


$ANm = $kamera [0][0];	$BNm = $kamera [1][0];	$CNm = $kamera [2][0];	$DNm = $kamera [3][0];	
$AHr = $kamera [0][1];	$BHr = $kamera [1][1];	$CHr = $kamera [2][1];	$DHr = $kamera [3][1];
$AMp = $kamera [0][2];	$BMp = $kamera [1][2];	$CMp = $kamera [2][2];	$DMp = $kamera [3][2];
$ASs = $kamera [0][3];	$BSs = $kamera [1][3];	$CSs = $kamera [2][3];	$DSs = $kamera [3][3];
$APr = $kamera [0][4];	$BPr = $kamera [1][4];	$CPr = $kamera [2][4];	$DPr = $kamera [3][4];
//Inisialisasi array untuk Canon 750 D = A, Canon 1200 D = B, Canon 760 D = C, Canon 5Dmark III = D

 //Perhitungan Harga
$HA1 = number_format($AHr / $AHr,2);
$HA2 = number_format($AHr / $BHr,2);
$HA3 = number_format($AHr / $CHr,2);
$HA4 = number_format($AHr / $DHr,2);

$HB1 = number_format($BHr / $AHr,2);
$HB2 = number_format($BHr / $BHr,2);
$HB3 = number_format($BHr / $CHr,2);
$HB4 = number_format($BHr / $DHr,2);

$HC1 = number_format($CHr / $AHr,2);
$HC2 = number_format($CHr / $BHr,2);
$HC3 = number_format($CHr / $CHr,2);
$HC4 = number_format($CHr / $DHr,2);

$HD1 = number_format($DHr / $AHr,2);
$HD2 = number_format($DHr / $BHr,2);
$HD3 = number_format($DHr / $CHr,2);
$HD4 = number_format($DHr / $DHr,2);

$THA =  number_format(($HA1+$HB1+$HC1+$HD1),2);
$THB =  number_format(($HA2+$HB2+$HC2+$HD2),2);
$THC =  number_format(($HA3+$HB3+$HC3+$HD3),2);
$THD =  number_format(($HA4+$HB4+$HC4+$HD4),2);


//Proses Normalisasi Harga
$NHA1 = number_format($HA1 / $THA,2);
$NHA2 = number_format($HB1 / $THA,2);
$NHA3 = number_format($HC1 / $THA,2);
$NHA4 = number_format($HD1 / $THA,2);
$TNHA = number_format($NHA1+$NHA2+$NHA3+$NHA4,2);


$NHB1 = number_format($HA2 / $THB,2);
$NHB2 = number_format($HB2 / $THB,2);
$NHB3 = number_format($HC2 / $THB,2);
$NHB4 = number_format($HD2 / $THB,2);
$TNHB = number_format($NHB1+$NHB2+$NHB3+$NHB4,2);


$NHC1 = number_format($HA3 / $THC,2);
$NHC2 = number_format($HB3 / $THC,2);
$NHC3 = number_format($HC3 / $THC,2);
$NHC4 = number_format($HD3 / $THC,2);
$TNHC = number_format($NHC1+$NHC2+$NHC3+$NHC4,2);


$NHD1 = number_format($HA4 / $THD,2);
$NHD2 = number_format($HB4 / $THD,2);
$NHD3 = number_format($HC4 / $THD,2);
$NHD4 = number_format($HD4 / $THD,2);
$TNHD = number_format($NHD1+$NHD2+$NHD3+$NHD4,2);

$RNHA = number_format(($NHA1+$NHB1+$NHC1+$NHD1)/4,2);
$RNHB = number_format(($NHA2+$NHB2+$NHC2+$NHD2)/4,2);
$RNHC = number_format(($NHA3+$NHB3+$NHC3+$NHD3)/4,2);
$RNHD = number_format(($NHA4+$NHB4+$NHC4+$NHD4)/4,2);


?>

<table border="1" style="width:50%">
	<tr>
		<td>Tabel Kamera</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>
	</tr>
  <tr>
    <td>harga</td>
	<td><?php echo $AHr;?></td>
	<td><?php echo $BHr;?></td>
	<td><?php echo $CHr;?></td>
	<td><?php echo $DHr;?></td>
	
	</tr>
	<tr>
    <td>Megapixel</td>
	<td><?php echo $AMp;?></td>
	<td><?php echo $BMp;?></td>
	<td><?php echo $CMp;?></td>
	<td><?php echo $DMp;?></td>
	
	</tr>
	<tr>
   <td>Sensor</td>
	<td><?php echo $ASs;?></td>
	<td><?php echo $BSs;?></td>
	<td><?php echo $CSs;?></td>
	<td><?php echo $DSs;?></td>
	
	</tr>
	<tr>
    <td>Processor</td>
	<td><?php echo $APr;?></td>
	<td><?php echo $BPr;?></td>
	<td><?php echo $CPr;?></td>
	<td><?php echo $DPr;?></td>

	</tr>
  </tr>
</table>
</br>

<h1>Kriteria - Harga<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Harga</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $HA1;?></td>
	<td><?php echo $HA2;?></td>
	<td><?php echo $HA3;?></td>
	<td><?php echo $HA4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $HB1;?></td>
	<td><?php echo $HB2;?></td>
	<td><?php echo $HB3;?></td>
	<td><?php echo $HB4;?></td>

	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $HC1;?></td>
	<td><?php echo $HC2;?></td>
	<td><?php echo $HC3;?></td>
	<td><?php echo $HC4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $HD1;?></td>
	<td><?php echo $HD2;?></td>
	<td><?php echo $HD3;?></td>
	<td><?php echo $HD4;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $THA;?></td>
	<td><?php echo $THB;?></td>
	<td><?php echo $THC;?></td>
	<td><?php echo $THD;?></td>
	
	</tr>
  </tr>
</table>

<h1>Normalisasi Kriteria - Harga<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Harga</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>
		<td>Rata Rata</td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $NHA1;?></td>
	<td><?php echo $NHB1;?></td>
	<td><?php echo $NHC1;?></td>
	<td><?php echo $NHD1;?></td>
	<td><?php echo $RNHA;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $NHA2;?></td>
	<td><?php echo $NHB2;?></td>
	<td><?php echo $NHC2;?></td>
	<td><?php echo $NHD2;?></td>
	<td><?php echo $RNHB;?></td>
	
	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $NHA3;?></td>
	<td><?php echo $NHB3;?></td>
	<td><?php echo $NHC3;?></td>
	<td><?php echo $NHD3;?></td>
	<td><?php echo $RNHC;?></td>
	

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $NHA4;?></td>
	<td><?php echo $NHB4;?></td>
	<td><?php echo $NHC4;?></td>
	<td><?php echo $NHD4;?></td>
	<td><?php echo $RNHD;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TNHA;?></td>
	<td><?php echo $TNHB;?></td>
	<td><?php echo $TNHC;?></td>
	<td><?php echo $TNHD;?></td>
	
	</tr>

  </tr>
</table>
<?PHP
//Kriteria MegaPixels
$MpA1 = number_format($AMp / $AMp,2);
$MpA2 = number_format($AMp / $BMp,2);
$MpA3 = number_format($AMp / $CMp,2);
$MpA4 = number_format($AMp / $DMp,2);

$MpB1 = number_format($BMp / $AMp,2);
$MpB2 = number_format($BMp / $BMp,2);
$MpB3 = number_format($BMp / $CMp,2);
$MpB4 = number_format($BMp / $DMp,2);

$MpC1 = number_format($CMp / $AMp,2);
$MpC2 = number_format($CMp / $BMp,2);
$MpC3 = number_format($CMp / $CMp,2);
$MpC4 = number_format($CMp / $DMp,2);

$MpD1 = number_format($DMp / $AMp,2);
$MpD2 = number_format($DMp / $BMp,2);
$MpD3 = number_format($DMp / $CMp,2);
$MpD4 = number_format($DMp / $DMp,2);

$TMpA =  number_format(($MpA1+$MpB1+$MpC1+$MpD1),2); //Total
$TMpB =  number_format(($MpA2+$MpB2+$MpC2+$MpD2),2); //Total
$TMpC =  number_format(($MpA3+$MpB3+$MpC3+$MpD3),2); //Total
$TMpD =  number_format(($MpA4+$MpB4+$MpC4+$MpD4),2); //Total


//Proses Normalisasi Harga
$NMpA1 = number_format($MpA1 / $TMpA,2);
$NMpA2 = number_format($MpB1 / $TMpA,2);
$NMpA3 = number_format($MpC1 / $TMpA,2);
$NMpA4 = number_format($MpD1 / $TMpA,2);
$TNMpA = number_format($NMpA1+$NMpA2+$NMpA3+$NMpA4,2); //Total


$NMpB1 = number_format($MpA2 / $TMpB,2);
$NMpB2 = number_format($MpB2 / $TMpB,2);
$NMpB3 = number_format($MpC2 / $TMpB,2);
$NMpB4 = number_format($MpD2 / $TMpB,2);
$TNMpB = number_format($NMpB1+$NMpB2+$NMpB3+$NMpB4,2); //Total


$NMpC1 = number_format($MpA3 / $TMpC,2);
$NMpC2 = number_format($MpB3 / $TMpC,2);
$NMpC3 = number_format($MpC3 / $TMpC,2);
$NMpC4 = number_format($MpD3 / $TMpC,2);
$TNMpC = number_format($NMpC1+$NMpC2+$NMpC3+$NMpC4,2); //Total


$NMpD1 = number_format($MpA4 / $TMpD,2);
$NMpD2 = number_format($MpB4 / $TMpD,2);
$NMpD3 = number_format($MpC4 / $TMpD,2);
$NMpD4 = number_format($MpD4 / $TMpD,2);
$TNMpD = number_format($NMpD1+$NMpD2+$NMpD3+$NMpD4,2); //Total

$RNMpA = number_format(($NMpA1+$NMpB1+$NMpC1+$NMpD1)/4,2); //Rata Rata
$RNMpB = number_format(($NMpA2+$NMpB2+$NMpC2+$NMpD2)/4,2); //Rata Rata
$RNMpC = number_format(($NMpA3+$NMpB3+$NMpC3+$NMpD3)/4,2); //Rata Rata
$RNMpD = number_format(($NMpA4+$NMpB4+$NMpC4+$NMpD4)/4,2); //Rata Rata

?>
<h1>Kriteria - megapixels<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Harga</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $MpA1;?></td>
	<td><?php echo $MpA2;?></td>
	<td><?php echo $MpA3;?></td>
	<td><?php echo $MpA4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $MpB1;?></td>
	<td><?php echo $MpB2;?></td>
	<td><?php echo $MpB3;?></td>
	<td><?php echo $MpB4;?></td>

	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $MpC1;?></td>
	<td><?php echo $MpC2;?></td>
	<td><?php echo $MpC3;?></td>
	<td><?php echo $MpC4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $MpD1;?></td>
	<td><?php echo $MpD2;?></td>
	<td><?php echo $MpD3;?></td>
	<td><?php echo $MpD4;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TMpA;?></td>
	<td><?php echo $TMpB;?></td>
	<td><?php echo $TMpC;?></td>
	<td><?php echo $TMpD;?></td>
	
	</tr>
  </tr>
</table>

<h1>Normalisasi Kriteria - Megapixels<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Harga</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>
		<td>Rata Rata</td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $NMpA1;?></td>
	<td><?php echo $NMpB1;?></td>
	<td><?php echo $NMpC1;?></td>
	<td><?php echo $NMpD1;?></td>
	<td><?php echo $RNMpA;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $NMpA2;?></td>
	<td><?php echo $NMpB2;?></td>
	<td><?php echo $NMpC2;?></td>
	<td><?php echo $NMpD2;?></td>
	<td><?php echo $RNMpB;?></td>
	
	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $NMpA3;?></td>
	<td><?php echo $NMpB3;?></td>
	<td><?php echo $NMpC3;?></td>
	<td><?php echo $NMpD3;?></td>
	<td><?php echo $RNMpC;?></td>
	

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $NMpA4;?></td>
	<td><?php echo $NMpB4;?></td>
	<td><?php echo $NMpC4;?></td>
	<td><?php echo $NMpD4;?></td>
	<td><?php echo $RNMpD;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TNMpA;?></td>
	<td><?php echo $TNMpB;?></td>
	<td><?php echo $TNMpC;?></td>
	<td><?php echo $TNMpD;?></td>
	
	</tr>

  </tr>
</table>

<?PHP
//Kriteria Sensor
$SsA1 = number_format($ASs / $ASs,2);
$SsA2 = number_format($ASs / $BSs,2);
$SsA3 = number_format($ASs / $CSs,2);
$SsA4 = number_format($ASs / $DSs,2);

$SsB1 = number_format($BSs / $ASs,2);
$SsB2 = number_format($BSs / $BSs,2);
$SsB3 = number_format($BSs / $CSs,2);
$SsB4 = number_format($BSs / $DSs,2);

$SsC1 = number_format($CSs / $ASs,2);
$SsC2 = number_format($CSs / $BSs,2);
$SsC3 = number_format($CSs / $CSs,2);
$SsC4 = number_format($CSs / $DSs,2);

$SsD1 = number_format($DSs / $ASs,2);
$SsD2 = number_format($DSs / $BSs,2);
$SsD3 = number_format($DSs / $CSs,2);
$SsD4 = number_format($DSs / $DSs,2);

$TSsA =  number_format(($SsA1+$SsB1+$SsC1+$SsD1),2);
$TSsB =  number_format(($SsA2+$SsB2+$SsC2+$SsD2),2);
$TSsC =  number_format(($SsA3+$SsB3+$SsC3+$SsD3),2);
$TSsD =  number_format(($SsA4+$SsB4+$SsC4+$SsD4),2);


//Proses Normalisasi Harga
$NSsA1 = number_format($SsA1 / $TSsA,2);
$NSsA2 = number_format($SsB1 / $TSsA,2);
$NSsA3 = number_format($SsC1 / $TSsA,2);
$NSsA4 = number_format($SsD1 / $TSsA,2);
$TNSsA = number_format($NSsA1+$NSsA2+$NSsA3+$NSsA4,2); //Total


$NSsB1 = number_format($SsA2 / $TSsB,2);
$NSsB2 = number_format($SsB2 / $TSsB,2);
$NSsB3 = number_format($SsC2 / $TSsB,2);
$NSsB4 = number_format($SsD2 / $TSsB,2);
$TNSsB = number_format($NSsB1+$NSsB2+$NSsB3+$NSsB4,2); //Total


$NSsC1 = number_format($SsA3 / $TSsC,2);
$NSsC2 = number_format($SsB3 / $TSsC,2);
$NSsC3 = number_format($SsC3 / $TSsC,2);
$NSsC4 = number_format($SsD3 / $TSsC,2);
$TNSsC = number_format($NSsC1+$NSsC2+$NSsC3+$NSsC4,2); //Total


$NSsD1 = number_format($SsA4 / $TSsD,2);
$NSsD2 = number_format($SsB4 / $TSsD,2);
$NSsD3 = number_format($SsC4 / $TSsD,2);
$NSsD4 = number_format($SsD4 / $TSsD,2);
$TNSsD = number_format($NSsD1+$NSsD2+$NSsD3+$NSsD4,2); //Total

$RNSsA = number_format(($NSsA1+$NSsB1+$NSsC1+$NSsD1)/4,2); //Rata Rata
$RNSsB = number_format(($NSsA2+$NSsB2+$NSsC2+$NSsD2)/4,2); //Rata Rata
$RNSsC = number_format(($NSsA3+$NSsB3+$NSsC3+$NSsD3)/4,2); //Rata Rata
$RNSsD = number_format(($NSsA4+$NSsB4+$NSsC4+$NSsD4)/4,2); //Rata Rata

?>
<h1>Kriteria - Sensor<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Sensor</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $SsA1;?></td>
	<td><?php echo $SsA2;?></td>
	<td><?php echo $SsA3;?></td>
	<td><?php echo $SsA4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $SsB1;?></td>
	<td><?php echo $SsB2;?></td>
	<td><?php echo $SsB3;?></td>
	<td><?php echo $SsB4;?></td>

	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $SsC1;?></td>
	<td><?php echo $SsC2;?></td>
	<td><?php echo $SsC3;?></td>
	<td><?php echo $SsC4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $SsD1;?></td>
	<td><?php echo $SsD2;?></td>
	<td><?php echo $SsD3;?></td>
	<td><?php echo $SsD4;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TSsA;?></td>
	<td><?php echo $TSsB;?></td>
	<td><?php echo $TSsC;?></td>
	<td><?php echo $TSsD;?></td>
	
	</tr>
  </tr>
</table>

<h1>Normalisasi Kriteria - Sensor<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Sensor</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>
		<td>Rata Rata</td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $NSsA1;?></td>
	<td><?php echo $NSsB1;?></td>
	<td><?php echo $NSsC1;?></td>
	<td><?php echo $NSsD1;?></td>
	<td><?php echo $RNSsA;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $NSsA2;?></td>
	<td><?php echo $NSsB2;?></td>
	<td><?php echo $NSsC2;?></td>
	<td><?php echo $NSsD2;?></td>
	<td><?php echo $RNSsB;?></td>
	
	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $NSsA3;?></td>
	<td><?php echo $NSsB3;?></td>
	<td><?php echo $NSsC3;?></td>
	<td><?php echo $NSsD3;?></td>
	<td><?php echo $RNSsC;?></td>
	

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $NSsA4;?></td>
	<td><?php echo $NSsB4;?></td>
	<td><?php echo $NSsC4;?></td>
	<td><?php echo $NSsD4;?></td>
	<td><?php echo $RNSsD;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TNSsA;?></td>
	<td><?php echo $TNSsB;?></td>
	<td><?php echo $TNSsC;?></td>
	<td><?php echo $TNSsD;?></td>
	
	</tr>

  </tr>
</table>

<?PHP
//Kriteria Processor
$PrA1 = number_format($APr / $APr,2);
$PrA2 = number_format($APr / $BPr,2);
$PrA3 = number_format($APr / $CPr,2);
$PrA4 = number_format($APr / $DPr,2);

$PrB1 = number_format($BPr / $APr,2);
$PrB2 = number_format($BPr / $BPr,2);
$PrB3 = number_format($BPr / $CPr,2);
$PrB4 = number_format($BPr / $DPr,2);

$PrC1 = number_format($CPr / $APr,2);
$PrC2 = number_format($CPr / $BPr,2);
$PrC3 = number_format($CPr / $CPr,2);
$PrC4 = number_format($CPr / $DPr,2);

$PrD1 = number_format($DPr / $APr,2);
$PrD2 = number_format($DPr / $BPr,2);
$PrD3 = number_format($DPr / $CPr,2);
$PrD4 = number_format($DPr / $DPr,2);

$TPrA =  number_format(($PrA1+$PrB1+$PrC1+$PrD1),2);
$TPrB =  number_format(($PrA2+$PrB2+$PrC2+$PrD2),2);
$TPrC =  number_format(($PrA3+$PrB3+$PrC3+$PrD3),2);
$TPrD =  number_format(($PrA4+$PrB4+$PrC4+$PrD4),2);


//Proses Normalisasi Harga
$NPrA1 = number_format($PrA1 / $TPrA,2);
$NPrA2 = number_format($PrB1 / $TPrA,2);
$NPrA3 = number_format($PrC1 / $TPrA,2);
$NPrA4 = number_format($PrD1 / $TPrA,2);
$TNPrA = number_format($NPrA1+$NPrA2+$NPrA3+$NPrA4,2); //Total


$NPrB1 = number_format($PrA2 / $TPrB,2);
$NPrB2 = number_format($PrB2 / $TPrB,2);
$NPrB3 = number_format($PrC2 / $TPrB,2);
$NPrB4 = number_format($PrD2 / $TPrB,2);
$TNPrB = number_format($NPrB1+$NPrB2+$NPrB3+$NPrB4,2); //Total


$NPrC1 = number_format($PrA3 / $TPrC,2);
$NPrC2 = number_format($PrB3 / $TPrC,2);
$NPrC3 = number_format($PrC3 / $TPrC,2);
$NPrC4 = number_format($PrD3 / $TPrC,2);
$TNPrC = number_format($NPrC1+$NPrC2+$NPrC3+$NPrC4,2); //Total


$NPrD1 = number_format($PrA4 / $TPrD,2);
$NPrD2 = number_format($PrB4 / $TPrD,2);
$NPrD3 = number_format($PrC4 / $TPrD,2);
$NPrD4 = number_format($PrD4 / $TPrD,2);
$TNPrD = number_format($NPrD1+$NPrD2+$NPrD3+$NPrD4,2); //Total

$RNPrA = number_format(($NPrA1+$NPrB1+$NPrC1+$NPrD1)/4,2); //Rata Rata
$RNPrB = number_format(($NPrA2+$NPrB2+$NPrC2+$NPrD2)/4,2); //Rata Rata
$RNPrC = number_format(($NPrA3+$NPrB3+$NPrC3+$NPrD3)/4,2); //Rata Rata
$RNPrD = number_format(($NPrA4+$NPrB4+$NPrC4+$NPrD4)/4,2); //Rata Rata

?>
<h1>Kriteria - Processor<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Processor</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $PrA1;?></td>
	<td><?php echo $PrA2;?></td>
	<td><?php echo $PrA3;?></td>
	<td><?php echo $PrA4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $PrB1;?></td>
	<td><?php echo $PrB2;?></td>
	<td><?php echo $PrB3;?></td>
	<td><?php echo $PrB4;?></td>

	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $PrC1;?></td>
	<td><?php echo $PrC2;?></td>
	<td><?php echo $PrC3;?></td>
	<td><?php echo $PrC4;?></td>

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $PrD1;?></td>
	<td><?php echo $PrD2;?></td>
	<td><?php echo $PrD3;?></td>
	<td><?php echo $PrD4;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TPrA;?></td>
	<td><?php echo $TPrB;?></td>
	<td><?php echo $TPrC;?></td>
	<td><?php echo $TPrD;?></td>
	
	</tr>
  </tr>
</table>

<h1>Normalisasi Kriteria - Processor<h1>
<table border="1" style="width:50%">
	<tr>
		<td>Processor</td>
		<td><?php echo $ANm;?></td>
		<td><?php echo $BNm;?></td>
		<td><?php echo $CNm;?></td>
		<td><?php echo $DNm;?></td>
		<td>Rata Rata</td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $NPrA1;?></td>
	<td><?php echo $NPrB1;?></td>
	<td><?php echo $NPrC1;?></td>
	<td><?php echo $NPrD1;?></td>
	<td><?php echo $RNPrA;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $NPrA2;?></td>
	<td><?php echo $NPrB2;?></td>
	<td><?php echo $NPrC2;?></td>
	<td><?php echo $NPrD2;?></td>
	<td><?php echo $RNPrB;?></td>
	
	
	</tr>
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $NPrA3;?></td>
	<td><?php echo $NPrB3;?></td>
	<td><?php echo $NPrC3;?></td>
	<td><?php echo $NPrD3;?></td>
	<td><?php echo $RNPrC;?></td>
	

	
	</tr>
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $NPrA4;?></td>
	<td><?php echo $NPrB4;?></td>
	<td><?php echo $NPrC4;?></td>
	<td><?php echo $NPrD4;?></td>
	<td><?php echo $RNPrD;?></td>


	</tr>
	<tr>
    <td>Total</td>
	<td><?php echo $TNPrA;?></td>
	<td><?php echo $TNPrB;?></td>
	<td><?php echo $TNPrC;?></td>
	<td><?php echo $TNPrD;?></td>
	
	</tr>

  </tr>
</table>
<?php

$P1 = number_format(($RNHA*$R1+$RNMpA*$R2+$RNSsA*$R3+$RNPrA*$R4),2); //Hasil Matriks 1
$P2 = number_format(($RNHB*$R1+$RNMpB*$R2+$RNSsB*$R3+$RNPrB*$R4),2); //Hasil Matriks 1
$P3 = number_format(($RNHC*$R1+$RNMpC*$R2+$RNSsC*$R3+$RNPrC*$R4),2); //Hasil Matriks 1
$P4 = number_format(($RNHD*$R1+$RNMpD*$R2+$RNSsD*$R3+$RNPrD*$R4),2); //Hasil Matriks 1


?>
<h1>Final Count AHP<h1>
<table border="1" style="width:100%">
	<tr>
		<td>Prioritas</td>
		<td>Harga</td>
		<td>Megapixels</td>
		<td>Sensor</td>
		<td>Processor</td>
		<td>Prioritas Dari User</td>
		<Td>Hasil Matriks</Td>

	</tr>
  <tr>
    <td><?php echo $ANm;?></td>
	<td><?php echo $RNHA;?></td>
	<td><?php echo $RNMpA;?></td>
	<td><?php echo $RNSsA;?></td>
	<td><?php echo $RNPrA;?></td>
	<td><?php echo $R1;?></td>
	<td><?php echo $P1;?></td>

	
	</tr>
	<tr>
    <td><?php echo $BNm;?></td>
	<td><?php echo $RNHB;?></td>
	<td><?php echo $RNMpB;?></td>
	<td><?php echo $RNSsB;?></td>
	<td><?php echo $RNPrB;?></td>
	<td><?php echo $R2;?></td>
	<td><?php echo $P2;?></td>
	</tr>
	
	<tr>
	<td><?php echo $CNm;?></td>
	<td><?php echo $RNHC;?></td>
	<td><?php echo $RNMpC;?></td>
	<td><?php echo $RNSsC;?></td>
	<td><?php echo $RNPrC;?></td>
	<td><?php echo $R3;?></td>
	<td><?php echo $P3;?></td>
	</tr>
	
	<tr>
    <td><?php echo $DNm;?></td>
	<td><?php echo $RNHD;?></td>
	<td><?php echo $RNMpD;?></td>
	<td><?php echo $RNSsD;?></td>
	<td><?php echo $RNPrD;?></td>
	<td><?php echo $R4;?></td>
	<td><?php echo $P4;?></td>
	</tr>


  </tr>
</table>
</Body>
</html>