<?php
if (isset($_POST['submit'])) {
//harga
if(isset($_POST['inlineRadioOptions1']))
{
$_POST['inlineRadioOptions1'];
}
else{ echo "<span>Please choose any radio button.</span>";}
//MP
if(isset($_POST['inlineRadioOptions2']))
{
$_POST['inlineRadioOptions2'];
}
else{ echo "<span>Please choose any radio button.</span>";}
//sensor
if(isset($_POST['inlineRadioOptions3']))
{
$_POST['inlineRadioOptions3'];
}
else{ echo "<span>Please choose any radio button.</span>";}
//processor
if(isset($_POST['inlineRadioOptions4']))
{
$_POST['inlineRadioOptions4'];
}
else{ echo "<span>Please choose any radio button.</span>";}
}
?>